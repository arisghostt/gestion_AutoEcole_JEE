package com.beans;

public class ConnectionResponse {
	private User user;
	private boolean conect;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public boolean isConect() {
		return conect;
	}
	public void setConect(boolean conect) {
		this.conect = conect;
	}
	public ConnectionResponse(User user, boolean conect) {
		//super();
		this.user = user;
		this.conect = conect;
	}
	
}
