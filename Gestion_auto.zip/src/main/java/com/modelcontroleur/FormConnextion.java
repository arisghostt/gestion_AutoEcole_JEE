package com.modelcontroleur;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.File;
import java.io.IOException;

import com.beans.ConnectionResponse;
import com.beans.Connexion;

/**
 * Servlet implementation class FormConnextion
 */
@WebServlet("/acceuil")
public class FormConnextion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormConnextion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connexion con = new Connexion();
		String username = request.getParameter("username");
		//String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		//Modification de la req�te avec les datas 
		
		//request.setAttribute("nom",username);
		//request.setAttribute("email",email);
		//request.setAttribute("password",password);
		//request.setAttribute("passwordConfirm", passwordConfirm); 
		
		
		// Transfert des datas � la vue 
		ConnectionResponse res = null;
		res = con.check(username, password);
		System.out.print(res.isConect());
		if(res.isConect()) {
			HttpSession session = request.getSession();
			session.setAttribute("userSession", res.getUser());
			this.getServletContext().getRequestDispatcher("/index.jsp").forward(request,response);
		}else {
			request.setAttribute("connect", con.check(username, password));
			this.getServletContext().getRequestDispatcher("/login.jsp").forward(request,response);
		}
			
	}

}
