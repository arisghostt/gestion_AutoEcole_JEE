package com.modelcontroleur;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


//import com.bdd.user;
import com.beans.User;
import com.dao.DaoFactory;
import com.dao.UtilisateurDao;

/**
 * Servlet implementation class Formulaire
 */
@WebServlet("/enregistrer")
public class Formulaire extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UtilisateurDao utilisateurDao;
	
	public void init() {
		DaoFactory daofactory = DaoFactory.getInstance();
		this.utilisateurDao = daofactory.getUtilisateurDao();
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Formulaire() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.getServletContext().getRequestDispatcher("/regist.jsp").forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	
		User user = new User();
		//user.setAdresse(request.getParameter("addresse"));
		user.setTelephone(request.getParameter("telephone"));
		user.setPrenom(request.getParameter("prenom"));
		user.setNom(request.getParameter("nom"));
		user.setPass(request.getParameter("pass"));
		user.setAddresse(request.getParameter("addresse"));
		user.setEmail(request.getParameter("email"));
		user.setRegion(request.getParameter("region"));
		this.utilisateurDao.addUser(user);
		this.getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
	}

}
