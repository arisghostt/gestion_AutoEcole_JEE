package com.dao;

import java.util.List;

//import com.beans.Comment;
import com.beans.User;

public interface UtilisateurDao {
	void addUser(User user);
	List<User> lister(); 
	//public void addComment(Comment comment);
}
