package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

//import com.beans.Comment;
import com.beans.User;

public class UtilisateurDaoImpl implements UtilisateurDao {
	private DaoFactory daoFactory;

	public UtilisateurDaoImpl(DaoFactory daoFactory) {
		this.daoFactory = daoFactory;
	}
	
	
	public void addUser(User user) {
		Connection connexion = null;
		PreparedStatement prepare = null;
		
		String type = "user";
		try {
			connexion = daoFactory.getConnection();
			prepare = connexion.prepareStatement("INSERT INTO user(nom,prenom,telephone,pass,email,region,addresse) VALUES(?,?,?,?,?,?,?);");
			int tel = Integer.parseInt(user.getTelephone());
			prepare.setString(1, user.getNom());
			prepare.setString(2, user.getPrenom());
			prepare.setInt(3, tel);
			prepare.setString(4, user.getPass());
			prepare.setString(5, user.getEmail());
			prepare.setString(6, user.getRegion());
			prepare.setString(7, user.getAddresse());
			prepare.executeUpdate();
			System.out.println("ajout effectuer avec succes");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("erreur pour ajout");
			System.out.println(user.getTelephone());
			e.printStackTrace();
		}
	}
	
public List <User> lister(){
		
		List <User> users = new ArrayList<User>();
	
		Connection connexion = null;
		Statement statement = null;
		ResultSet result = null;
		
		
		try {
			connexion = daoFactory.getConnection();
			statement =  connexion.createStatement();
			
			//execution de la requete
			result = statement.executeQuery("SELECT nom,telephone,pass,prenom,region,addresse,email FROM user;");
			System.out.println("connection ok");
			while(result.next()) {
				String addresse = result.getString("addresse");
				String email = result.getString("email");
				String nom = result.getString("nom");
				String prenom = result.getString("prenom");
				String region = result.getString("region");
				String telephone =  result.getString("telephone");
				String pass = result.getString("pass");
				 
				User user = new User();
				user.setPrenom(prenom);				
				user.setNom(nom);
				user.setTelephone(telephone);
				user.setPass(pass);
				user.setAddresse(addresse);
				user.setRegion(region);
				user.setEmail(email);
				//user.setCon("ok");
				users.add(user);
			}
			
		}catch(SQLException e) {
		
			System.out.println("error au niveau de la requete ");
		}finally {
			//fermer la connection
			try {
				if(result != null)
					result.close();
				if(statement != null)
					statement.close();
				if(connexion != null)
					connexion.close();
			}catch(SQLException ignore) {
				
			}
		}
		
		
		return users;
	}

	/*public void addComment(Comment comment) {
		Connection connexion = null;
		PreparedStatement prepare = null;
	
		String type = "comment";
		try {
			connexion = daoFactory.getConnection();
			prepare = connexion.prepareStatement("INSERT INTO comments(nom,telephone,email,sujet,message) VALUES(?,?,?,?,?);");
			int tel = Integer.parseInt(comment.getTel());
			prepare.setString(1, comment.getNom());
			//prepare.setString(2, comment.getTel());
			prepare.setInt(2, tel);
			prepare.setString(3, comment.getEmail());
			prepare.setString(4, comment.getSujet());
			prepare.setString(5, comment.getMessage());
			prepare.executeUpdate();
			System.out.println("ajout effectuer avec succes");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("erreur pour ajout");
			System.out.println(comment.getTel());
			e.printStackTrace();
		}
}*/
}
